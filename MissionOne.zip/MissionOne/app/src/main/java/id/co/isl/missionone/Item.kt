package id.co.isl.missionone

data class Item (val name: String?, val image: Int?)