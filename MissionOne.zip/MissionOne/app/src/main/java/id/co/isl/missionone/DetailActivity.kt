package id.co.isl.missionone

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.bumptech.glide.Glide
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info
import kotlinx.android.synthetic.main.activity_main.*

class DetailActivity : AppCompatActivity(),AnkoLogger {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        info(intent.getIntExtra("CLUB_SORT",0))

        val clubIndex = intent.getIntExtra("CLUB_SORT",0)

        val name = resources.getStringArray(R.array.club_name)
        val image = resources.obtainTypedArray(R.array.club_image)
        val description = resources.getStringArray(R.array.club_description)

        Glide.with(this).load(image.getResourceId(clubIndex,0)).into(club_logo)
        club_name.text = name[clubIndex]
        club_description.text = description[clubIndex]

    }

}